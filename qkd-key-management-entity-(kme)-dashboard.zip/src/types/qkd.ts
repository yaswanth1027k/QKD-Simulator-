export type NodeId = 
  | 'substation-alpha'
  | 'data-center-central'
  | 'hydro-reservoir'
  | 'fed-clearinghouse'
  | 'metro-emergency'
  | 'nuclear-unit-4';

export interface CriticalNode {
  id: NodeId;
  name: string;
  category: 'Power Utility' | 'Data Center' | 'Water System' | 'Finance' | 'Emergency' | 'Nuclear';
  saeId: string; // Secure Application Entity ID (ETSI 014)
  location: string;
  distanceKm: number;
  status: 'ONLINE' | 'STANDBY' | 'SYNCING' | 'INTERCEPTED';
  iconType: string;
  voltageOrSpec: string;
}

export interface QuantumKeyMaterial {
  keyId: string;
  keyHex: string;
  keyBytes: number[];
  keyBitLength: number;
  timestamp: string;
  sourceNodeId: NodeId;
  targetNodeId: NodeId;
  sourceSaeId: string;
  targetSaeId: string;
  ttlSeconds: number;
  remainingTtl: number;
  entropyBits: number;
  protocol: 'ETSI-GS-QKD-014' | 'BB84-Decoy' | 'COW-QKD';
  origin: 'API' | 'LOCAL_FALLBACK' | 'CLIENT_SYNTH';
}

export interface Etsi014Response {
  keys: Array<{
    key_ID: string;
    key: string; // base64 or hex
  }>;
  key_stream_id?: string;
}

export interface SystemTelemetry {
  qberPercent: number;
  keyGenRateKbps: number;
  fiberDistanceKm: number;
  photonCountRateMhz: number;
  keyBufferCount: number;
  siftingRatioPercent: number;
  rawKeyRateKbps: number;
  coincidenceWindowNs: number;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  level: 'INFO' | 'SUCCESS' | 'WARN' | 'CRITICAL';
  category: 'API' | 'QKD_PHY' | 'CRYPTO' | 'ATTACK' | 'ETSI_014';
  message: string;
  details?: string;
}

export interface EncryptionResult {
  algorithm: 'OTP' | 'AES-256-GCM';
  plaintext: string;
  ciphertextHex: string;
  ciphertextBase64: string;
  ivHex?: string;
  authTagHex?: string;
  usedKeyId: string;
  timestamp: string;
  binaryPlaintext: string;
  binaryCiphertext: string;
  binaryKey: string;
}
