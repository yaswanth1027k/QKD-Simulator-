import React, { useEffect, useRef } from 'react';
import { 
  ShieldAlert, 
  AlertTriangle, 
  Activity, 
  Radio, 
  Flame, 
  Eye, 
  CheckCircle, 
  Sliders, 
  ZapOff,
  Crosshair
} from 'lucide-react';
import { soundFx } from '../utils/qkdCrypto';

interface QuantumInterceptionSimulatorProps {
  isAttackActive: boolean;
  onToggleAttack: () => void;
  qberPercent: number;
  qberHistory: number[];
  attackType: 'PNS' | 'INTERCEPT_RESEND' | 'DETECTOR_BLIND';
  setAttackType: (type: 'PNS' | 'INTERCEPT_RESEND' | 'DETECTOR_BLIND') => void;
}

export const QuantumInterceptionSimulator: React.FC<QuantumInterceptionSimulatorProps> = ({
  isAttackActive,
  onToggleAttack,
  qberPercent,
  qberHistory,
  attackType,
  setAttackType
}) => {
  const chartCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Live QBER Real-time Canvas Line Chart
  useEffect(() => {
    const canvas = chartCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    ctx.clearRect(0, 0, width, height);

    // Draw Grid Lines
    ctx.strokeStyle = 'rgba(30, 41, 59, 0.6)';
    ctx.lineWidth = 1;
    for (let y = 15; y < height; y += 25) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Draw 11.0% Threshold Danger Line
    // Max scale: 25% QBER
    const thresholdY = height - (11.0 / 25.0) * height;
    ctx.beginPath();
    ctx.setLineDash([4, 4]);
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.8)';
    ctx.lineWidth = 1.5;
    ctx.moveTo(0, thresholdY);
    ctx.lineTo(width, thresholdY);
    ctx.stroke();
    ctx.setLineDash([]);

    // Label Threshold Line
    ctx.font = '9px "JetBrains Mono", monospace';
    ctx.fillStyle = '#ef4444';
    ctx.fillText('CRITICAL ABORT THRESHOLD: 11.0% QBER', 10, thresholdY - 4);

    // Draw QBER History Waveform
    if (qberHistory.length > 1) {
      ctx.beginPath();
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = isAttackActive ? '#ef4444' : '#06b6d4';
      ctx.shadowColor = isAttackActive ? '#ef4444' : '#06b6d4';
      ctx.shadowBlur = 8;

      const step = width / (qberHistory.length - 1);
      qberHistory.forEach((val, index) => {
        const x = index * step;
        const normalizedVal = Math.min(Math.max(val, 0), 25.0);
        const y = height - (normalizedVal / 25.0) * (height - 15) - 8;
        if (index === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });
      ctx.stroke();
      ctx.shadowBlur = 0; // reset

      // Draw current point dot
      const lastVal = qberHistory[qberHistory.length - 1];
      const lastX = width - 1;
      const lastY = height - (Math.min(lastVal, 25.0) / 25.0) * (height - 15) - 8;
      ctx.beginPath();
      ctx.arc(lastX, lastY, 4, 0, Math.PI * 2);
      ctx.fillStyle = isAttackActive ? '#ef4444' : '#22d3ee';
      ctx.fill();
    }
  }, [qberHistory, isAttackActive]);

  return (
    <div className={`bg-[#0f172a]/60 border rounded-lg p-4 sm:p-5 cyber-panel-glow transition-all ${
      isAttackActive ? 'border-red-600/80 attack-active-glow' : 'border-slate-800'
    }`}>
      {/* Panel Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 mb-4 border-b border-slate-800 gap-3">
        <div className="flex items-center gap-2.5">
          <div className={`p-2 rounded border ${
            isAttackActive 
              ? 'bg-red-950/80 border-red-500/80 text-red-400' 
              : 'bg-[#020617] border-cyan-500/40 text-cyan-400'
          }`}>
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xs uppercase text-slate-400 tracking-widest font-bold font-mono">
                Threat & Disturbance Interceptor
              </h2>
              {isAttackActive && (
                <span className="tag-immersive border-red-500 text-red-400 bg-red-950/80 animate-pulse font-bold">
                  EAVESDROPPER ACTIVE
                </span>
              )}
            </div>
            <p className="text-sm font-bold text-white tracking-wide font-mono">
              BB84 Quantum State Collapse & Real-time QBER
            </p>
          </div>
        </div>

        {/* Attack Simulator Toggle Button */}
        <div className="flex items-center gap-2 font-mono">
          <button
            id="simulate-eavesdropper-button"
            onClick={onToggleAttack}
            className={`px-4 py-2 rounded text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer ${
              isAttackActive
                ? 'bg-red-600 hover:bg-red-500 text-white shadow-[0_0_20px_rgba(239,68,68,0.6)] active:scale-95'
                : 'bg-[#020617] hover:bg-slate-900 text-red-400 border border-red-500/50 hover:border-red-400 active:scale-95'
            }`}
          >
            {isAttackActive ? (
              <>
                <Flame className="w-4 h-4 animate-bounce" />
                <span>TERMINATE EAVESDROPPER TAP</span>
              </>
            ) : (
              <>
                <Crosshair className="w-4 h-4 text-red-400" />
                <span>Simulate Eavesdropper Attack</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Red High-Alert Banner (Triggered when QBER > 11% / Attack Active) */}
      {isAttackActive && (
        <div 
          id="quantum-attack-alert-banner"
          className="mb-4 bg-[#020617] border-2 border-red-600 rounded-lg p-4 text-red-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-[0_0_25px_rgba(239,68,68,0.4)]"
        >
          <div className="flex items-start gap-3 font-mono">
            <div className="p-2 rounded bg-red-950 border border-red-500 text-red-400 mt-0.5 sm:mt-0">
              <AlertTriangle className="w-6 h-6 animate-spin" style={{ animationDuration: '3s' }} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-red-300 tracking-wide flex items-center gap-2">
                CRITICAL QUANTUM ALARM: QUANTUM WAVEFORM DISTURBED
              </h3>
              <p className="text-xs text-red-400 mt-0.5">
                Eavesdropping Tap Detected — QBER (<strong>{qberPercent.toFixed(1)}%</strong>) exceeds BB84 theoretical security ceiling (<strong>11.0%</strong>).
              </p>
              <div className="mt-1 flex flex-wrap gap-3 text-[11px] text-red-400 font-mono">
                <span>• No-Cloning Violated</span>
                <span>• Photon Polarization Decayed</span>
                <span className="font-bold text-red-300">• Key Harvester Aborted Automatically</span>
              </div>
            </div>
          </div>
          <div className="px-3 py-1.5 rounded bg-red-950 border border-red-500 text-red-300 font-mono text-xs font-bold whitespace-nowrap self-stretch sm:self-auto text-center uppercase tracking-widest">
            KEY ABORTED (ITS VOID)
          </div>
        </div>
      )}

      {/* QBER Gauge & Real-time Timeline */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 font-mono">
        
        {/* QBER Gauge & Status Meters */}
        <div className="lg:col-span-5 bg-[#020617] border border-slate-800 rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 uppercase tracking-wider flex items-center gap-1.5 text-[11px] font-bold">
              <Activity className="w-3.5 h-3.5 text-cyan-400" /> Quantum Bit Error Rate
            </span>
            <span className={`tag-immersive ${
              qberPercent > 11.0 
                ? 'border-red-500 text-red-400 bg-red-950/60 font-bold' 
                : 'border-emerald-500 text-emerald-400 bg-emerald-950/60 font-bold'
            }`}>
              {qberPercent > 11.0 ? 'STATE UNSECURE' : 'SECURE (BB84 ITS)'}
            </span>
          </div>

          {/* QBER Value & Visual Gauge Bar */}
          <div className="space-y-2">
            <div className="flex items-baseline justify-between">
              <div className="text-3xl font-bold tracking-tight">
                <span className={qberPercent > 11.0 ? 'text-red-400 font-extrabold' : 'text-cyan-400'}>
                  {qberPercent.toFixed(1)}%
                </span>
                <span className="text-xs text-slate-500 font-normal ml-2">QBER</span>
              </div>
              <div className="text-xs text-slate-400 text-right">
                <div>Nominal: <strong className="text-emerald-400">1.8%</strong></div>
                <div>Ceiling: <strong className="text-red-400">11.0%</strong></div>
              </div>
            </div>

            {/* Custom Multi-Color Range Gauge Bar */}
            <div className="relative w-full h-3.5 bg-[#000] rounded-full overflow-hidden border border-slate-800">
              {/* Green Safe Zone (0% to 11.0% -> 44% of bar) */}
              <div className="absolute left-0 top-0 bottom-0 w-[44%] bg-emerald-950/40 border-r border-emerald-500/40" />
              {/* Red Hazard Zone (11.0% to 25.0% -> 56% of bar) */}
              <div className="absolute right-0 top-0 bottom-0 w-[56%] bg-red-950/30" />
              
              {/* Active Indicator Fill */}
              <div 
                className={`h-full rounded-full transition-all duration-300 ${
                  qberPercent > 11.0 
                    ? 'bg-gradient-to-r from-emerald-500 via-amber-500 to-red-600 shadow-[0_0_12px_rgba(239,68,68,0.8)]' 
                    : 'bg-gradient-to-r from-emerald-500 to-cyan-400'
                }`}
                style={{ width: `${Math.min((qberPercent / 25.0) * 100, 100)}%` }}
              />
            </div>

            {/* Scale Markings */}
            <div className="flex justify-between text-[10px] text-slate-500 px-0.5">
              <span>0% (Ideal)</span>
              <span className="text-emerald-400">4.5%</span>
              <span className="text-red-400 font-bold">11.0% (Limit)</span>
              <span>25.0% (Noise)</span>
            </div>
          </div>

          {/* Attack Vector Selector */}
          <div className="pt-2 border-t border-slate-800/80 space-y-2">
            <div className="text-[11px] text-slate-400 uppercase tracking-wider flex items-center justify-between font-bold">
              <span>Simulated Attack Vector:</span>
              <Sliders className="w-3 h-3 text-cyan-400" />
            </div>
            <div className="grid grid-cols-3 gap-1.5 text-[10px]">
              {[
                { id: 'PNS', label: 'Photon Number Split', desc: 'Attenuated tap' },
                { id: 'INTERCEPT_RESEND', label: 'Intercept-Resend', desc: 'State measurement' },
                { id: 'DETECTOR_BLIND', label: 'Detector Blind', desc: 'SPAD CW saturation' }
              ].map((v) => (
                <button
                  key={v.id}
                  onClick={() => {
                    soundFx.playClick();
                    setAttackType(v.id as typeof attackType);
                  }}
                  className={`p-2 rounded border text-left transition-all ${
                    attackType === v.id
                      ? 'bg-[#0f172a] text-cyan-300 border-cyan-500/60 font-bold'
                      : 'bg-[#020617] text-slate-400 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="truncate font-bold">{v.id}</div>
                  <div className="text-[9px] text-slate-500 truncate mt-0.5">{v.desc}</div>
                </button>
              ))}
            </div>
          </div>

        </div>

        {/* Real-time QBER Historical Waveform Chart */}
        <div className="lg:col-span-7 bg-[#020617] border border-slate-800 rounded-lg p-4 flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 flex items-center gap-1.5 font-bold uppercase text-[11px]">
              <Eye className="w-3.5 h-3.5 text-cyan-400" /> Live QBER Waveform & Photon Telemetry
            </span>
            <span className="tag-immersive">
              500ms Window
            </span>
          </div>

          <div className="relative rounded bg-[#000] border border-slate-800 p-2 overflow-hidden">
            <canvas
              ref={chartCanvasRef}
              width={480}
              height={140}
              className="w-full h-[135px] block"
            />
          </div>

          {/* Diagnostic Stats Grid */}
          <div className="grid grid-cols-3 gap-2 pt-1">
            <div className="p-2 rounded bg-[#0f172a] border border-slate-800 text-center">
              <div className="text-[10px] text-slate-400 uppercase tracking-wider">Decoherence</div>
              <div className={`text-xs font-bold mt-0.5 ${isAttackActive ? 'text-red-400' : 'text-emerald-400'}`}>
                {isAttackActive ? '+14.2 dB (ALERT)' : '0.04 dB (NOMINAL)'}
              </div>
            </div>
            <div className="p-2 rounded bg-[#0f172a] border border-slate-800 text-center">
              <div className="text-[10px] text-slate-400 uppercase tracking-wider">Eve Intercept</div>
              <div className={`text-xs font-bold mt-0.5 ${isAttackActive ? 'text-red-400' : 'text-slate-400'}`}>
                {isAttackActive ? '99.98% DETECTED' : '0.00%'}
              </div>
            </div>
            <div className="p-2 rounded bg-[#0f172a] border border-slate-800 text-center">
              <div className="text-[10px] text-slate-400 uppercase tracking-wider">No-Cloning</div>
              <div className={`text-xs font-bold mt-0.5 ${isAttackActive ? 'text-red-400' : 'text-emerald-400'}`}>
                {isAttackActive ? 'COLLAPSED' : 'PROTECTED'}
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
