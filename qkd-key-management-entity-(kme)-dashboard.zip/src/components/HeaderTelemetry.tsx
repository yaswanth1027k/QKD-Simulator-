import React from 'react';
import { 
  ShieldCheck, 
  Activity, 
  Wifi, 
  WifiOff, 
  Clock, 
  Volume2, 
  VolumeX, 
  RefreshCw, 
  Layers, 
  Radio, 
  Database,
  Lock,
  Cpu
} from 'lucide-react';
import { SystemTelemetry } from '../types/qkd';
import { soundFx } from '../utils/qkdCrypto';

interface HeaderTelemetryProps {
  apiUrl: string;
  setApiUrl: (url: string) => void;
  connectionStatus: 'CONNECTED' | 'COLD_START' | 'OFFLINE' | 'LOCAL_FALLBACK';
  coldStartCountdown: number;
  onTestConnection: () => void;
  isTesting: boolean;
  telemetry: SystemTelemetry;
  isAttackActive: boolean;
  soundEnabled: boolean;
  setSoundEnabled: (val: boolean) => void;
  onOpenAuditLog: () => void;
}

export const HeaderTelemetry: React.FC<HeaderTelemetryProps> = ({
  apiUrl,
  setApiUrl,
  connectionStatus,
  coldStartCountdown,
  onTestConnection,
  isTesting,
  telemetry,
  isAttackActive,
  soundEnabled,
  setSoundEnabled,
  onOpenAuditLog
}) => {
  return (
    <header className="border-b border-slate-800 bg-[#0f172a]/80 backdrop-blur-md sticky top-0 z-40">
      {/* Top Banner: Infrastructure Brand & API Config */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          
          {/* Brand & Security Level */}
          <div className="flex items-center space-x-3">
            <div className={`p-2.5 rounded-lg border transition-colors ${
              isAttackActive 
                ? 'bg-red-950/60 border-red-600 text-red-400 attack-active-glow' 
                : 'bg-[#020617] border-cyan-500/50 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.2)]'
            }`}>
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-0.5">
                <span className="text-[11px] font-bold tracking-tight text-cyan-400">
                  QKD-KME // CRITICAL-INFRA-SYS
                </span>
                <span className="tag-immersive">ETSI GS QKD 014</span>
                <span className="text-[10px] uppercase font-bold text-emerald-400 flex items-center gap-1">
                  <Lock className="w-2.5 h-2.5" /> ITS SECURE
                </span>
              </div>
              <h1 className="text-base sm:text-lg font-bold tracking-tight text-white flex items-center gap-2">
                Quantum Key Management Entity
                <span className="text-xs font-normal text-slate-400 hidden sm:inline">
                  — High-Assurance Control Node
                </span>
              </h1>
            </div>
          </div>

          {/* API Configuration Bar & Live Status */}
          <div className="flex flex-wrap items-center gap-2.5">
            <div className="flex items-center bg-[#020617] border border-slate-800 rounded p-1 max-w-full sm:w-auto">
              <span className="text-[11px] text-slate-400 px-2 flex items-center gap-1 select-none font-mono">
                <Cpu className="w-3.5 h-3.5 text-cyan-400" /> KME:
              </span>
              <input
                id="kme-api-endpoint-input"
                type="text"
                value={apiUrl}
                onChange={(e) => setApiUrl(e.target.value)}
                placeholder="https://quantum-key-distribution-7bv6.onrender.com"
                className="bg-[#0f172a] text-cyan-300 text-xs px-2.5 py-1.5 rounded border border-slate-800 focus:outline-none focus:border-cyan-500 w-52 sm:w-64"
                title="QKD KME API Target Endpoint"
              />
              <button
                id="kme-api-test-button"
                onClick={onTestConnection}
                disabled={isTesting}
                title="Verify KME REST Handshake"
                className="ml-1.5 px-2.5 py-1.5 bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/50 text-cyan-300 text-xs font-bold rounded flex items-center gap-1 transition-all disabled:opacity-50 uppercase tracking-wider"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
                <span>{isTesting ? 'Ping...' : 'Test Sync'}</span>
              </button>
            </div>

            {/* Live Connection Status Badge */}
            <div className="flex items-center gap-2">
              {connectionStatus === 'CONNECTED' && (
                <div 
                  id="kme-status-badge"
                  className="px-3 py-1.5 rounded bg-[#020617] border border-emerald-500/50 text-emerald-400 text-xs flex items-center gap-2"
                >
                  <span className="status-pulse"></span>
                  <span className="text-xs uppercase tracking-widest text-emerald-400 font-bold">System Synchronized</span>
                </div>
              )}

              {connectionStatus === 'COLD_START' && (
                <div 
                  id="kme-status-badge"
                  className="px-3 py-1.5 rounded bg-amber-950/60 border border-amber-500/40 text-amber-300 text-xs flex items-center gap-2 shadow-[0_0_12px_rgba(245,158,11,0.2)]"
                  title="Backend is awakening on Render free tier (can take up to 40s). Fallback engine active."
                >
                  <Clock className="w-3.5 h-3.5 animate-spin text-amber-400" />
                  <span className="uppercase tracking-wider font-bold">COLD-START SYNC ({coldStartCountdown}s)</span>
                </div>
              )}

              {connectionStatus === 'LOCAL_FALLBACK' && (
                <div 
                  id="kme-status-badge"
                  className="px-3 py-1.5 rounded bg-[#020617] border border-cyan-500/40 text-cyan-300 text-xs flex items-center gap-2"
                  title="Running on high-fidelity client quantum simulation engine"
                >
                  <span className="status-pulse"></span>
                  <span className="uppercase tracking-widest font-bold text-cyan-300">SYNTH SIMULATOR</span>
                </div>
              )}

              {connectionStatus === 'OFFLINE' && (
                <div 
                  id="kme-status-badge"
                  className="px-3 py-1.5 rounded bg-rose-950/60 border border-rose-500/40 text-rose-400 text-xs flex items-center gap-2"
                >
                  <WifiOff className="w-3.5 h-3.5" />
                  <span className="uppercase tracking-wider font-bold">OFFLINE</span>
                </div>
              )}

              {/* Sound Toggle */}
              <button
                id="audio-synth-toggle-button"
                onClick={() => {
                  soundFx.enabled = !soundEnabled;
                  setSoundEnabled(!soundEnabled);
                  if (!soundEnabled) soundFx.playClick();
                }}
                className="p-1.5 rounded bg-[#020617] border border-slate-800 text-slate-400 hover:text-cyan-300 hover:border-cyan-500/40 transition-colors"
                title={soundEnabled ? 'Quantum Audio Effects: Enabled' : 'Quantum Audio Effects: Muted'}
              >
                {soundEnabled ? <Volume2 className="w-4 h-4 text-cyan-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
              </button>

              {/* Audit Log Button */}
              <button
                id="audit-log-toggle-button"
                onClick={onOpenAuditLog}
                className="px-2.5 py-1.5 rounded bg-[#020617] border border-slate-800 text-slate-300 hover:text-cyan-300 hover:border-cyan-500/40 transition-colors text-xs flex items-center gap-1.5"
                title="View Telemetry Audit Log"
              >
                <Layers className="w-3.5 h-3.5 text-cyan-400" />
                <span className="hidden sm:inline uppercase tracking-wider text-[11px] font-bold">Audit Log</span>
              </button>
            </div>
          </div>
        </div>

        {/* Global Immersive Metrics Bar */}
        <div className="mt-3 border border-slate-800 rounded-lg overflow-hidden bg-[#0f172a]/40 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 divide-y sm:divide-y-0 sm:divide-x divide-slate-800">
          
          {/* Metric 1: Global QBER */}
          <div className={`p-3.5 transition-colors ${
            telemetry.qberPercent > 11.0 
              ? 'bg-red-950/50 text-red-300' 
              : 'bg-transparent text-slate-200'
          }`}>
            <div className="text-[11px] uppercase tracking-wider text-slate-400 font-bold flex items-center justify-between">
              <span>Global QBER</span>
              <span className={`h-2 w-2 rounded-full ${telemetry.qberPercent > 11.0 ? 'bg-red-500 animate-ping' : 'bg-emerald-400'}`} />
            </div>
            <div className="text-2xl font-bold mt-1 tracking-tight flex items-baseline gap-1">
              <span className={telemetry.qberPercent > 11.0 ? 'text-red-400' : 'text-cyan-400'}>
                {telemetry.qberPercent.toFixed(2)}%
              </span>
              <span className="text-[10px] text-slate-400 font-normal">
                (Ceil: 11%)
              </span>
            </div>
          </div>

          {/* Metric 2: Key Generation Rate */}
          <div className="p-3.5 bg-transparent text-slate-200">
            <div className="text-[11px] uppercase tracking-wider text-slate-400 font-bold flex items-center justify-between">
              <span>Key Gen Rate</span>
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
            </div>
            <div className="text-2xl font-bold mt-1 text-cyan-400 tracking-tight flex items-baseline gap-1.5">
              <span>{isAttackActive ? '0.00' : telemetry.keyGenRateKbps.toFixed(2)}</span>
              <span className="text-xs text-slate-400 font-normal">kbps</span>
            </div>
          </div>

          {/* Metric 3: Fiber Distance */}
          <div className="p-3.5 bg-transparent text-slate-200">
            <div className="text-[11px] uppercase tracking-wider text-slate-400 font-bold flex items-center justify-between">
              <span>Fiber Distance</span>
              <Radio className="w-3.5 h-3.5 text-cyan-400" />
            </div>
            <div className="text-2xl font-bold mt-1 text-cyan-400 tracking-tight flex items-baseline gap-1.5">
              <span>{telemetry.fiberDistanceKm.toFixed(1)}</span>
              <span className="text-xs text-slate-400 font-normal">km SMF</span>
            </div>
          </div>

          {/* Metric 4: Photon Count Rate */}
          <div className="p-3.5 bg-transparent text-slate-200">
            <div className="text-[11px] uppercase tracking-wider text-slate-400 font-bold flex items-center justify-between">
              <span>Photon Rate</span>
              <span className="text-[10px] text-cyan-400">1550nm</span>
            </div>
            <div className="text-2xl font-bold mt-1 text-cyan-400 tracking-tight flex items-baseline gap-1.5">
              <span>{telemetry.photonCountRateMhz.toFixed(2)}</span>
              <span className="text-xs text-slate-400 font-normal">MHz</span>
            </div>
          </div>

          {/* Metric 5: Key Buffer Depth / Entropy Pool */}
          <div className="p-3.5 bg-transparent text-slate-200">
            <div className="text-[11px] uppercase tracking-wider text-slate-400 font-bold flex items-center justify-between">
              <span>Entropy Pool</span>
              <Database className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <div className="text-2xl font-bold mt-1 text-emerald-400 tracking-tight flex items-baseline gap-1.5">
              <span>98.9%</span>
              <span className="text-xs text-slate-400 font-normal">({telemetry.keyBufferCount} keys)</span>
            </div>
          </div>

          {/* Metric 6: Sifting Yield */}
          <div className="p-3.5 bg-transparent text-slate-200">
            <div className="text-[11px] uppercase tracking-wider text-slate-400 font-bold flex items-center justify-between">
              <span>Sifting Yield</span>
              <span className="text-[10px] text-emerald-400">BB84</span>
            </div>
            <div className="text-2xl font-bold mt-1 text-cyan-400 tracking-tight flex items-baseline gap-1.5">
              <span>{telemetry.siftingRatioPercent.toFixed(1)}%</span>
              <span className="text-xs text-slate-400 font-normal">sifted</span>
            </div>
          </div>

        </div>
      </div>
    </header>
  );
};
