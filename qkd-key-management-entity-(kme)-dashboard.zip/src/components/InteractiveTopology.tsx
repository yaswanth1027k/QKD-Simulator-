import React, { useEffect, useRef, useState } from 'react';
import { 
  Network, 
  ArrowRightLeft, 
  Radio, 
  ShieldAlert, 
  Zap, 
  Server, 
  Droplets, 
  Landmark, 
  Atom, 
  Info,
  CheckCircle2
} from 'lucide-react';
import { CriticalNode, NodeId } from '../types/qkd';
import { CRITICAL_NODES } from '../data/infrastructureNodes';
import { soundFx } from '../utils/qkdCrypto';

interface InteractiveTopologyProps {
  sourceNodeId: NodeId;
  targetNodeId: NodeId;
  onSelectSource: (id: NodeId) => void;
  onSelectTarget: (id: NodeId) => void;
  isAttackActive: boolean;
  qberPercent: number;
}

export const InteractiveTopology: React.FC<InteractiveTopologyProps> = ({
  sourceNodeId,
  targetNodeId,
  onSelectSource,
  onSelectTarget,
  isAttackActive,
  qberPercent
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [activeTab, setActiveTab] = useState<'visual' | 'nodes'>('visual');

  const sourceNode = CRITICAL_NODES.find(n => n.id === sourceNodeId) || CRITICAL_NODES[0];
  const targetNode = CRITICAL_NODES.find(n => n.id === targetNodeId) || CRITICAL_NODES[1];

  // Calculate actual link distance between nodes
  const linkDistanceKm = Math.abs(sourceNode.distanceKm - targetNode.distanceKm) + 20.0;
  const opticalAttenuationDb = (linkDistanceKm * 0.19).toFixed(2); // ~0.19 dB/km at 1550nm standard single-mode fiber

  // Swap source and target
  const handleSwapNodes = () => {
    soundFx.playClick();
    const prevSrc = sourceNodeId;
    onSelectSource(targetNodeId);
    onSelectTarget(prevSrc);
  };

  // Canvas Photon Pulse & Quantum Channel Animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let tick = 0;

    // Photon packets in quantum channel
    interface Photon {
      xRatio: number; // 0 to 1
      speed: number;
      polarization: '|H⟩' | '|V⟩' | '|+⟩' | '|-⟩';
      color: string;
      disturbed: boolean;
    }

    const photons: Photon[] = [];
    const polarizations: Array<'|H⟩' | '|V⟩' | '|+⟩' | '|-⟩'> = ['|H⟩', '|V⟩', '|+⟩', '|-⟩'];

    for (let i = 0; i < 8; i++) {
      photons.push({
        xRatio: i / 8,
        speed: 0.003 + Math.random() * 0.002,
        polarization: polarizations[i % 4],
        color: '#06b6d4',
        disturbed: false
      });
    }

    const render = () => {
      tick++;
      const width = canvas.width;
      const height = canvas.height;

      ctx.clearRect(0, 0, width, height);

      const aliceX = 70;
      const aliceY = height / 2;
      const bobX = width - 70;
      const bobY = height / 2;
      const eveX = width / 2;
      const eveY = height / 2 - 35;

      // 1. Classical Public Channel (Dashed Green/Blue Line)
      ctx.beginPath();
      ctx.setLineDash([6, 6]);
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.3)';
      ctx.lineWidth = 2;
      ctx.moveTo(aliceX, aliceY + 28);
      ctx.lineTo(bobX, bobY + 28);
      ctx.stroke();
      ctx.setLineDash([]);

      // Label Classical Channel
      ctx.font = '10px "JetBrains Mono", monospace';
      ctx.fillStyle = '#64748b';
      ctx.textAlign = 'center';
      ctx.fillText('CLASSICAL AUTHENTICATED CHANNEL (BASE SIFTING & ERROR CORRECTION)', width / 2, aliceY + 44);

      // 2. Quantum Fiber Optical Link (SMF-28 1550nm)
      ctx.beginPath();
      ctx.strokeStyle = isAttackActive ? 'rgba(239, 68, 68, 0.8)' : 'rgba(6, 182, 212, 0.7)';
      ctx.lineWidth = isAttackActive ? 4 : 3;
      ctx.shadowColor = isAttackActive ? '#ef4444' : '#06b6d4';
      ctx.shadowBlur = isAttackActive ? 12 : 8;
      ctx.moveTo(aliceX, aliceY - 10);
      ctx.lineTo(bobX, bobY - 10);
      ctx.stroke();
      ctx.shadowBlur = 0; // reset

      // Label Quantum Channel
      ctx.fillStyle = isAttackActive ? '#fca5a5' : '#67e8f9';
      ctx.fillText(
        isAttackActive 
          ? 'QUANTUM CHANNEL (EAVESDROPPER INTERCEPTING / STATE COLLAPSE)' 
          : 'QUANTUM CHANNEL (1550nm POLARIZED SINGLE PHOTON STREAM)',
        width / 2,
        aliceY - 24
      );

      // 3. Render Eve Node if Attack is Active
      if (isAttackActive) {
        // Beam splitter tap rays
        ctx.beginPath();
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.85)';
        ctx.lineWidth = 2;
        ctx.setLineDash([3, 3]);
        ctx.moveTo(eveX, aliceY - 10);
        ctx.lineTo(eveX, eveY);
        ctx.stroke();
        ctx.setLineDash([]);

        // Eve Circle
        ctx.beginPath();
        ctx.arc(eveX, eveY, 18, 0, Math.PI * 2);
        ctx.fillStyle = '#450a0a';
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2;
        ctx.shadowColor = '#ef4444';
        ctx.shadowBlur = 10;
        ctx.fill();
        ctx.stroke();
        ctx.shadowBlur = 0;

        // Eve Icon text
        ctx.fillStyle = '#f87171';
        ctx.font = 'bold 9px "JetBrains Mono", monospace';
        ctx.fillText('EVE', eveX, eveY + 3);

        // Beam Splitter label
        ctx.fillStyle = '#ef4444';
        ctx.font = '8px "JetBrains Mono", monospace';
        ctx.fillText('PNS / BEAM SPLITTER', eveX, eveY - 24);
      }

      // 4. Update and Draw Moving Photons
      photons.forEach((p) => {
        p.xRatio += p.speed;
        if (p.xRatio > 1) {
          p.xRatio = 0;
          p.polarization = polarizations[Math.floor(Math.random() * 4)];
          p.disturbed = false;
        }

        const px = aliceX + p.xRatio * (bobX - aliceX);
        const py = aliceY - 10;

        // Check if passing Eve in attack mode
        if (isAttackActive && px > eveX - 10) {
          p.disturbed = true;
        }

        // Draw Photon particle
        ctx.beginPath();
        ctx.arc(px, py, isAttackActive && p.disturbed ? 5 : 4, 0, Math.PI * 2);
        ctx.fillStyle = isAttackActive && p.disturbed ? '#ef4444' : '#22d3ee';
        ctx.shadowColor = isAttackActive && p.disturbed ? '#ef4444' : '#06b6d4';
        ctx.shadowBlur = 10;
        ctx.fill();
        ctx.shadowBlur = 0;

        // Draw polarization state label above photon
        if (tick % 60 < 45) {
          ctx.font = '8px "JetBrains Mono", monospace';
          ctx.fillStyle = isAttackActive && p.disturbed ? '#fca5a5' : '#a5f3fc';
          ctx.fillText(p.disturbed ? '|?⟩' : p.polarization, px, py - 8);
        }
      });

      // 5. Draw Alice Transmitter Node
      ctx.beginPath();
      ctx.arc(aliceX, aliceY - 10, 24, 0, Math.PI * 2);
      ctx.fillStyle = '#0f172a';
      ctx.strokeStyle = '#06b6d4';
      ctx.lineWidth = 2;
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#38bdf8';
      ctx.font = 'bold 10px "JetBrains Mono", monospace';
      ctx.fillText('ALICE', aliceX, aliceY - 12);
      ctx.font = '8px "JetBrains Mono", monospace';
      ctx.fillStyle = '#94a3b8';
      ctx.fillText('Tx KME', aliceX, aliceY);

      // 6. Draw Bob Receiver Node
      ctx.beginPath();
      ctx.arc(bobX, bobY - 10, 24, 0, Math.PI * 2);
      ctx.fillStyle = '#0f172a';
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 2;
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#34d399';
      ctx.font = 'bold 10px "JetBrains Mono", monospace';
      ctx.fillText('BOB', bobX, bobY - 12);
      ctx.font = '8px "JetBrains Mono", monospace';
      ctx.fillStyle = '#94a3b8';
      ctx.fillText('Rx KME', bobX, bobY);

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [isAttackActive]);

  const getNodeIcon = (iconType: string) => {
    switch (iconType) {
      case 'Zap': return <Zap className="w-4 h-4 text-amber-400" />;
      case 'Server': return <Server className="w-4 h-4 text-cyan-400" />;
      case 'Droplets': return <Droplets className="w-4 h-4 text-blue-400" />;
      case 'Landmark': return <Landmark className="w-4 h-4 text-emerald-400" />;
      case 'Atom': return <Atom className="w-4 h-4 text-purple-400" />;
      default: return <Radio className="w-4 h-4 text-cyan-400" />;
    }
  };

  return (
    <div className="bg-[#0f172a]/60 border border-slate-800 rounded-lg p-4 sm:p-5 cyber-panel-glow">
      {/* Panel Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 mb-4 border-b border-slate-800 gap-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded bg-[#020617] border border-cyan-500/40 text-cyan-400">
            <Network className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xs uppercase text-slate-400 tracking-widest font-bold font-mono">
                Node Topology // Active Optical Links
              </h2>
            </div>
            <p className="text-sm font-bold text-white tracking-wide">
              Critical Infrastructure Quantum Channel Matrix
            </p>
          </div>
        </div>

        {/* Tags & View mode toggle */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex gap-1.5 font-mono">
            <span className="tag-immersive">SRC: {sourceNode.saeId}</span>
            <span className="tag-immersive">TRG: {targetNode.saeId}</span>
          </div>

          <div className="flex items-center bg-[#020617] rounded p-1 border border-slate-800 text-xs font-mono">
            <button
              onClick={() => setActiveTab('visual')}
              className={`px-3 py-1 rounded transition-all uppercase tracking-wider text-[11px] ${
                activeTab === 'visual' ? 'bg-[#0f172a] text-cyan-300 border border-cyan-500/50 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Quantum Path
            </button>
            <button
              onClick={() => setActiveTab('nodes')}
              className={`px-3 py-1 rounded transition-all uppercase tracking-wider text-[11px] ${
                activeTab === 'nodes' ? 'bg-[#0f172a] text-cyan-300 border border-cyan-500/50 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Nodes ({CRITICAL_NODES.length})
            </button>
          </div>
        </div>
      </div>

      {/* Node Selectors (Source vs Target) */}
      <div className="grid grid-cols-1 md:grid-cols-11 gap-3 items-center mb-4 font-mono">
        
        {/* Source Node Selector */}
        <div className="md:col-span-5 bg-[#020617] border border-slate-800 rounded-lg p-3.5 relative">
          <div className="flex items-center justify-between text-xs text-cyan-400 mb-1.5 font-bold">
            <span className="flex items-center gap-1.5 uppercase tracking-wider">
              <span className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_#06b6d4]"></span>
              ALICE (TRANSMITTER KME)
            </span>
            <span className="tag-immersive text-[9px]">{sourceNode.saeId}</span>
          </div>
          <select
            id="source-node-select"
            value={sourceNodeId}
            onChange={(e) => {
              soundFx.playClick();
              onSelectSource(e.target.value as NodeId);
            }}
            className="w-full bg-[#0f172a] border border-slate-700 text-white text-xs font-mono font-bold rounded px-3 py-2 focus:outline-none focus:border-cyan-500 cursor-pointer"
          >
            {CRITICAL_NODES.map((node) => (
              <option key={node.id} value={node.id} disabled={node.id === targetNodeId}>
                {node.name} [{node.category}]
              </option>
            ))}
          </select>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
            <span>Location: {sourceNode.location}</span>
            <span className="text-cyan-300 font-semibold">{sourceNode.voltageOrSpec}</span>
          </div>
        </div>

        {/* Swap / Directional Link Center */}
        <div className="md:col-span-1 flex flex-col items-center justify-center">
          <button
            id="swap-nodes-button"
            onClick={handleSwapNodes}
            className="p-2 rounded bg-[#020617] hover:bg-slate-800 text-cyan-400 border border-slate-700 hover:border-cyan-500 transition-all hover:scale-105 active:scale-95 shadow-[0_0_10px_rgba(6,182,212,0.15)]"
            title="Swap Quantum Link Direction"
          >
            <ArrowRightLeft className="w-4 h-4" />
          </button>
          <span className="text-[9px] text-slate-500 mt-1 font-bold">SWAP</span>
        </div>

        {/* Target Node Selector */}
        <div className="md:col-span-5 bg-[#020617] border border-slate-800 rounded-lg p-3.5 relative">
          <div className="flex items-center justify-between text-xs text-emerald-400 mb-1.5 font-bold">
            <span className="flex items-center gap-1.5 uppercase tracking-wider">
              <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_#10b981]"></span>
              BOB (RECEIVER KME)
            </span>
            <span className="tag-immersive text-[9px]">{targetNode.saeId}</span>
          </div>
          <select
            id="target-node-select"
            value={targetNodeId}
            onChange={(e) => {
              soundFx.playClick();
              onSelectTarget(e.target.value as NodeId);
            }}
            className="w-full bg-[#0f172a] border border-slate-700 text-white text-xs font-mono font-bold rounded px-3 py-2 focus:outline-none focus:border-emerald-500 cursor-pointer"
          >
            {CRITICAL_NODES.map((node) => (
              <option key={node.id} value={node.id} disabled={node.id === sourceNodeId}>
                {node.name} [{node.category}]
              </option>
            ))}
          </select>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
            <span>Location: {targetNode.location}</span>
            <span className="text-emerald-300 font-semibold">{targetNode.voltageOrSpec}</span>
          </div>
        </div>

      </div>

      {/* Visual Canvas / Network Map */}
      {activeTab === 'visual' ? (
        <div className="relative rounded-lg overflow-hidden bg-[#020617] border border-slate-800 p-2">
          {/* Canvas for dynamic photon stream & Eve tap */}
          <canvas
            ref={canvasRef}
            width={720}
            height={190}
            className="w-full h-[180px] sm:h-[190px] block"
          />

          {/* Real-time Link Telemetry Floating Pill */}
          <div className="absolute bottom-3 left-3 right-3 flex flex-wrap items-center justify-between gap-2 px-3 py-2 bg-[#0f172a]/90 backdrop-blur-md rounded border border-slate-800 text-[11px] font-mono text-slate-300">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1 text-cyan-400 font-bold">
                <Radio className="w-3.5 h-3.5" /> Direct SMF: {linkDistanceKm.toFixed(1)} km
              </span>
              <span className="text-slate-600">|</span>
              <span className="text-slate-400">
                Loss: <strong className="text-white">{opticalAttenuationDb} dB</strong>
              </span>
              <span className="text-slate-600">|</span>
              <span className="text-slate-400">
                Dark Counts: <strong className="text-emerald-400">18.4 Hz</strong>
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="tag-immersive text-cyan-300 border-cyan-500/40">
                1550.12 nm (C-Band)
              </span>
            </div>
          </div>
        </div>
      ) : (
        /* Grid of all Infrastructure Nodes */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 font-mono">
          {CRITICAL_NODES.map((node) => {
            const isSrc = node.id === sourceNodeId;
            const isTgt = node.id === targetNodeId;
            return (
              <div 
                key={node.id}
                className={`p-3.5 rounded-lg border transition-all ${
                  isSrc 
                    ? 'bg-[#020617] border-cyan-500/60 shadow-[0_0_12px_rgba(6,182,212,0.2)]' 
                    : isTgt 
                    ? 'bg-[#020617] border-emerald-500/60 shadow-[0_0_12px_rgba(16,185,129,0.2)]'
                    : 'bg-[#020617]/70 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded bg-[#0f172a] border border-slate-800">
                      {getNodeIcon(node.iconType)}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white leading-tight font-mono">
                        {node.name.split('(')[0]}
                      </h4>
                      <span className="text-[10px] text-cyan-400">{node.saeId}</span>
                    </div>
                  </div>
                  {isSrc && (
                    <span className="tag-immersive border-cyan-500 text-cyan-300 font-bold">
                      ALICE (SRC)
                    </span>
                  )}
                  {isTgt && (
                    <span className="tag-immersive border-emerald-500 text-emerald-300 font-bold">
                      BOB (TGT)
                    </span>
                  )}
                </div>
                <div className="mt-2 text-[11px] text-slate-400">
                  <p>{node.location}</p>
                  <p className="text-[10px] text-slate-500 mt-0.5 truncate">{node.voltageOrSpec}</p>
                </div>
                <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between">
                  <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> QKD Synced
                  </span>
                  <div className="flex items-center gap-1.5">
                    {!isSrc && (
                      <button
                        onClick={() => onSelectSource(node.id)}
                        className="px-2 py-0.5 text-[10px] rounded bg-[#0f172a] hover:bg-cyan-900/60 hover:text-cyan-300 text-slate-300 border border-slate-700"
                      >
                        Set Alice
                      </button>
                    )}
                    {!isTgt && (
                      <button
                        onClick={() => onSelectTarget(node.id)}
                        className="px-2 py-0.5 text-[10px] rounded bg-[#0f172a] hover:bg-emerald-900/60 hover:text-emerald-300 text-slate-300 border border-slate-700"
                      >
                        Set Bob
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
