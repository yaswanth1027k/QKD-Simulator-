import React, { useState } from 'react';
import { 
  KeyRound, 
  Copy, 
  Check, 
  Sparkles, 
  Terminal, 
  ShieldCheck, 
  Clock, 
  Database, 
  Code2, 
  Cpu, 
  Fingerprint, 
  Layers,
  AlertCircle
} from 'lucide-react';
import { QuantumKeyMaterial, NodeId } from '../types/qkd';
import { CRITICAL_NODES } from '../data/infrastructureNodes';
import { soundFx } from '../utils/qkdCrypto';

interface EtsiKeyConsoleProps {
  activeKey: QuantumKeyMaterial | null;
  keyBuffer: QuantumKeyMaterial[];
  onGenerateKey: (bitLength: number) => Promise<void>;
  isGenerating: boolean;
  sourceNodeId: NodeId;
  targetNodeId: NodeId;
  isAttackActive: boolean;
  onSelectBufferKey: (key: QuantumKeyMaterial) => void;
}

export const EtsiKeyConsole: React.FC<EtsiKeyConsoleProps> = ({
  activeKey,
  keyBuffer,
  onGenerateKey,
  isGenerating,
  sourceNodeId,
  targetNodeId,
  isAttackActive,
  onSelectBufferKey
}) => {
  const [selectedBitLength, setSelectedBitLength] = useState<number>(256);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [showJsonPayload, setShowJsonPayload] = useState<boolean>(false);
  const [activeViewMode, setActiveViewMode] = useState<'hex' | 'binary' | 'bytegrid'>('hex');
  const [hoveredByteIndex, setHoveredByteIndex] = useState<number | null>(null);

  const sourceNode = CRITICAL_NODES.find(n => n.id === sourceNodeId) || CRITICAL_NODES[0];
  const targetNode = CRITICAL_NODES.find(n => n.id === targetNodeId) || CRITICAL_NODES[1];

  const handleCopy = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    soundFx.playClick();
    setTimeout(() => setCopiedField(null), 2000);
  };

  // Construct ETSI GS QKD 014 standard JSON payload structure
  const etsiJsonPayload = activeKey ? {
    status: 'SUCCESS',
    timestamp: activeKey.timestamp,
    master_SAE_ID: sourceNode.saeId,
    slave_SAE_ID: targetNode.saeId,
    key_stream_id: 'urn:etsi:qkd:014:stream:' + activeKey.keyId.split(':').pop()?.substring(0, 8),
    keys: [
      {
        key_ID: activeKey.keyId,
        key: activeKey.keyHex,
        size_bits: activeKey.keyBitLength,
        entropy_shannon: activeKey.entropyBits,
        ttl_seconds: activeKey.ttlSeconds
      }
    ],
    metadata: {
      standard: 'ETSI GS QKD 014 V1.1.1',
      protocol: activeKey.protocol,
      security_proof: 'Information-Theoretically Secure (ITS)',
      coincidence_resolved: true
    }
  } : null;

  return (
    <div className="bg-[#0f172a]/60 border border-slate-800 rounded-lg p-4 sm:p-5 cyber-panel-glow flex flex-col">
      {/* Panel Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 mb-4 border-b border-slate-800 gap-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded bg-[#020617] border border-cyan-500/40 text-cyan-400">
            <KeyRound className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xs uppercase text-slate-400 tracking-widest font-bold font-mono">
                ETSI GS QKD 014 Console
              </h2>
              <span className="tag-immersive">REST v1.1.1</span>
            </div>
            <p className="text-sm font-bold text-white tracking-wide font-mono">
              Quantum Key Provisioning Interface
            </p>
          </div>
        </div>

        {/* Action Controls & Key Size */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center bg-[#020617] rounded p-1 border border-slate-800 text-xs font-mono">
            <span className="text-slate-400 px-2 select-none uppercase text-[10px]">Size:</span>
            {[256, 512].map((len) => (
              <button
                key={len}
                onClick={() => {
                  setSelectedBitLength(len);
                  soundFx.playClick();
                }}
                className={`px-2.5 py-1 rounded transition-all text-xs font-bold ${
                  selectedBitLength === len 
                    ? 'bg-[#0f172a] text-cyan-300 border border-cyan-500/50' 
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {len}b
              </button>
            ))}
          </div>

          <button
            id="generate-quantum-key-button"
            onClick={() => onGenerateKey(selectedBitLength)}
            disabled={isGenerating || isAttackActive}
            className={`px-4 py-2 rounded text-xs font-mono font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer ${
              isAttackActive 
                ? 'bg-red-950/80 border border-red-500/50 text-red-400 cursor-not-allowed'
                : 'bg-cyan-500 hover:bg-cyan-400 text-black shadow-[0_0_15px_rgba(6,182,212,0.4)] active:scale-95 disabled:opacity-50'
            }`}
          >
            {isGenerating ? (
              <>
                <span className="animate-spin h-3.5 w-3.5 border-2 border-black border-t-transparent rounded-full" />
                <span>Harvesting...</span>
              </>
            ) : isAttackActive ? (
              <>
                <AlertCircle className="w-4 h-4" />
                <span>Key Aborted</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Generate Key</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Key Display Box */}
      {activeKey ? (
        <div className="space-y-4 flex-1 flex flex-col font-mono">
          
          {/* Key ID & Metadata Header */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 bg-[#020617] border border-slate-800 rounded-lg p-3.5">
            
            {/* Key ID with Copy */}
            <div className="lg:col-span-8 space-y-1">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span className="flex items-center gap-1.5 text-cyan-400 font-bold uppercase tracking-wider text-[11px]">
                  <Fingerprint className="w-3.5 h-3.5" /> Key ID:
                </span>
                <span className="tag-immersive border-emerald-500/50 text-emerald-400">
                  ITS VERIFIED
                </span>
              </div>
              <div className="flex items-center gap-2">
                <div 
                  id="key-id-output"
                  className="w-full bg-[#0f172a] border border-slate-800 text-cyan-300 font-mono text-xs px-3 py-2 rounded truncate select-all"
                >
                  {activeKey.keyId}
                </div>
                <button
                  onClick={() => handleCopy(activeKey.keyId, 'keyId')}
                  className="p-2 rounded bg-[#0f172a] hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 transition-colors"
                  title="Copy Key ID"
                >
                  {copiedField === 'keyId' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-cyan-400" />}
                </button>
              </div>
            </div>

            {/* Quick Metrics (Entropy & TTL) */}
            <div className="lg:col-span-4 grid grid-cols-2 gap-2">
              <div className="p-2 rounded bg-[#0f172a] border border-slate-800 text-center">
                <div className="text-[10px] text-slate-400 uppercase tracking-wider">Entropy</div>
                <div className="text-sm font-bold text-emerald-400 mt-0.5">
                  {activeKey.entropyBits.toFixed(2)} <span className="text-[9px] text-slate-500">/ 8.0</span>
                </div>
              </div>
              <div className="p-2 rounded bg-[#0f172a] border border-slate-800 text-center">
                <div className="text-[10px] text-slate-400 uppercase tracking-wider">TTL</div>
                <div className="text-sm font-bold text-amber-400 mt-0.5 flex items-center justify-center gap-1">
                  <Clock className="w-3 h-3" /> {activeKey.remainingTtl}s
                </div>
              </div>
            </div>

          </div>

          {/* Raw Hex Key Material Output Box (Immersive Hex Block) */}
          <div className="bg-[#020617] border border-slate-800 rounded-lg p-3.5 space-y-2 flex-1">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <span className="text-cyan-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5" /> Raw Quantum Key ({activeKey.keyBitLength}-bit):
                </span>
                <span className="tag-immersive">
                  {activeKey.keyBytes.length} Bytes
                </span>
              </div>

              {/* View mode toggle */}
              <div className="flex items-center bg-[#0f172a] rounded p-0.5 border border-slate-800 text-[11px]">
                <button
                  onClick={() => setActiveViewMode('hex')}
                  className={`px-2 py-0.5 rounded uppercase text-[10px] ${activeViewMode === 'hex' ? 'bg-[#020617] text-cyan-300 font-bold border border-cyan-500/40' : 'text-slate-400'}`}
                >
                  Hex String
                </button>
                <button
                  onClick={() => setActiveViewMode('bytegrid')}
                  className={`px-2 py-0.5 rounded uppercase text-[10px] ${activeViewMode === 'bytegrid' ? 'bg-[#020617] text-cyan-300 font-bold border border-cyan-500/40' : 'text-slate-400'}`}
                >
                  32B Grid
                </button>
                <button
                  onClick={() => setActiveViewMode('binary')}
                  className={`px-2 py-0.5 rounded uppercase text-[10px] ${activeViewMode === 'binary' ? 'bg-[#020617] text-cyan-300 font-bold border border-cyan-500/40' : 'text-slate-400'}`}
                >
                  Binary
                </button>
              </div>
            </div>

            {/* Key Content Viewers */}
            {activeViewMode === 'hex' && (
              <div className="relative">
                <div 
                  id="key-material-hex-output"
                  className="hex-block-immersive select-all tracking-wider font-mono text-xs sm:text-sm shadow-inner"
                >
                  {activeKey.keyHex}
                </div>
                <button
                  onClick={() => handleCopy(activeKey.keyHex, 'keyHex')}
                  className="absolute top-2.5 right-2.5 px-2.5 py-1 bg-[#0f172a] hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-700 rounded text-xs flex items-center gap-1 transition-colors uppercase font-bold"
                  title="Copy Hex Key"
                >
                  {copiedField === 'keyHex' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {activeViewMode === 'bytegrid' && (
              <div className="space-y-2">
                <div className="grid grid-cols-8 sm:grid-cols-16 gap-1 bg-[#000] border-l-3 border-emerald-500 p-3 rounded">
                  {activeKey.keyBytes.map((byte, idx) => (
                    <div
                      key={idx}
                      onMouseEnter={() => setHoveredByteIndex(idx)}
                      onMouseLeave={() => setHoveredByteIndex(null)}
                      className={`p-1 text-center text-xs rounded transition-all cursor-pointer ${
                        hoveredByteIndex === idx 
                          ? 'bg-cyan-500 text-black font-bold scale-110 z-10' 
                          : 'bg-[#0f172a] text-emerald-400 border border-slate-800 hover:border-cyan-500'
                      }`}
                    >
                      {byte.toString(16).padStart(2, '0').toUpperCase()}
                    </div>
                  ))}
                </div>
                {hoveredByteIndex !== null && (
                  <div className="text-[11px] text-cyan-300 bg-[#0f172a] px-3 py-1.5 rounded border border-slate-800 flex items-center justify-between">
                    <span>Byte [{hoveredByteIndex}]: 0x{activeKey.keyBytes[hoveredByteIndex].toString(16).padStart(2, '0').toUpperCase()}</span>
                    <span>Dec: {activeKey.keyBytes[hoveredByteIndex]}</span>
                    <span>Bin: {activeKey.keyBytes[hoveredByteIndex].toString(2).padStart(8, '0')}</span>
                  </div>
                )}
              </div>
            )}

            {activeViewMode === 'binary' && (
              <div className="bg-[#000] border-l-3 border-emerald-500 text-emerald-400 text-[11px] p-3 rounded max-h-24 overflow-y-auto leading-relaxed break-all">
                {activeKey.keyBytes.map(b => b.toString(2).padStart(8, '0')).join(' ')}
              </div>
            )}

            {/* Immersive Timestamp & Verified Signature Line */}
            <div className="flex flex-wrap items-center justify-between gap-2 text-[10px] text-emerald-400 uppercase tracking-wider pt-1 border-t border-slate-800">
              <span className="flex items-center gap-1">
                TIMESTAMP: {activeKey.timestamp}
              </span>
              <span className="text-emerald-400 font-bold">
                // SIGNATURE: VERIFIED (ETSI-QKD)
              </span>
            </div>

          </div>

          {/* Key Buffer & ETSI JSON Payload Inspector */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400 flex items-center gap-1 uppercase tracking-wider text-[10px]">
                <Database className="w-3.5 h-3.5 text-cyan-400" /> Buffer ({keyBuffer.length}):
              </span>
              <div className="flex items-center gap-1 max-w-[280px] overflow-x-auto py-0.5">
                {keyBuffer.slice(0, 5).map((bufKey, idx) => (
                  <button
                    key={bufKey.keyId}
                    onClick={() => {
                      soundFx.playClick();
                      onSelectBufferKey(bufKey);
                    }}
                    className={`px-2 py-1 text-[10px] rounded border transition-colors ${
                      bufKey.keyId === activeKey.keyId
                        ? 'bg-[#0f172a] text-cyan-300 border-cyan-500 font-bold'
                        : 'bg-[#020617] text-slate-400 border-slate-800 hover:border-slate-700'
                    }`}
                    title={`Select key ${bufKey.keyId.substring(0, 24)}...`}
                  >
                    Key #{idx + 1}
                  </button>
                ))}
              </div>
            </div>

            <button
              id="view-etsi-json-toggle"
              onClick={() => setShowJsonPayload(!showJsonPayload)}
              className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 px-2.5 py-1 rounded bg-[#020617] border border-slate-800 hover:border-cyan-500/50 uppercase text-[10px] font-bold tracking-wider"
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>{showJsonPayload ? 'Hide ETSI JSON' : 'Inspect ETSI 014 JSON'}</span>
            </button>
          </div>

          {/* Expandable ETSI GS QKD 014 JSON Payload Inspector */}
          {showJsonPayload && etsiJsonPayload && (
            <div className="bg-[#020617] border border-slate-800 rounded-lg p-3.5 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span className="text-cyan-400 flex items-center gap-1.5 font-bold uppercase text-[11px]">
                  <Terminal className="w-3.5 h-3.5" /> ETSI GS QKD 014 REST Response Specification
                </span>
                <button
                  onClick={() => handleCopy(JSON.stringify(etsiJsonPayload, null, 2), 'etsiJson')}
                  className="px-2 py-0.5 text-[10px] rounded bg-[#0f172a] hover:bg-slate-800 text-cyan-300 uppercase font-bold"
                >
                  {copiedField === 'etsiJson' ? 'Copied' : 'Copy JSON'}
                </button>
              </div>
              <pre className="bg-[#000] text-emerald-400 text-xs p-3 rounded overflow-x-auto max-h-48 border-l-3 border-emerald-500">
                {JSON.stringify(etsiJsonPayload, null, 2)}
              </pre>
            </div>
          )}

        </div>
      ) : (
        /* Empty State */
        <div className="bg-[#020617] border border-dashed border-slate-800 rounded-lg p-8 text-center space-y-3 font-mono">
          <div className="inline-flex p-3 rounded bg-[#0f172a] border border-slate-800 text-slate-500">
            <KeyRound className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">No Active Quantum Key Material</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
              Initiate a quantum key exchange handshake across the active optical link to harvest single photons for ETSI GS QKD 014 key tokens.
            </p>
          </div>
          <button
            onClick={() => onGenerateKey(selectedBitLength)}
            disabled={isGenerating || isAttackActive}
            className="px-4 py-2 rounded bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-bold uppercase tracking-wider transition-all shadow-[0_0_15px_rgba(6,182,212,0.3)]"
          >
            Harvest Quantum Key (256-bit)
          </button>
        </div>
      )}
    </div>
  );
};
