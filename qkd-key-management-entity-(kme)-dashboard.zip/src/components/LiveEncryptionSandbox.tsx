import React, { useState } from 'react';
import { 
  Lock, 
  Unlock, 
  ShieldCheck, 
  Send, 
  Copy, 
  Check, 
  Terminal, 
  Cpu, 
  Sparkles, 
  Layers, 
  Key, 
  RefreshCw, 
  CheckCircle2,
  FileCode
} from 'lucide-react';
import { QuantumKeyMaterial, EncryptionResult, NodeId } from '../types/qkd';
import { COMMAND_PRESETS, CRITICAL_NODES } from '../data/infrastructureNodes';
import { 
  encryptOneTimePad, 
  decryptOneTimePad, 
  encryptAesGcm, 
  decryptAesGcm, 
  soundFx 
} from '../utils/qkdCrypto';

interface LiveEncryptionSandboxProps {
  activeKey: QuantumKeyMaterial | null;
  sourceNodeId: NodeId;
  targetNodeId: NodeId;
  onKeyConsumed?: () => void;
}

export const LiveEncryptionSandbox: React.FC<LiveEncryptionSandboxProps> = ({
  activeKey,
  sourceNodeId,
  targetNodeId,
  onKeyConsumed
}) => {
  const [plaintextInput, setPlaintextInput] = useState<string>(
    'GRID_CMD: 500kV TRANS_BUS_4 -> OPEN_BREAKER_SYNC [VOLTAGE: 520kV | LOAD: 840MW]'
  );
  const [selectedAlgorithm, setSelectedAlgorithm] = useState<'OTP' | 'AES-256-GCM'>('OTP');
  const [encryptionResult, setEncryptionResult] = useState<EncryptionResult | null>(null);
  const [decryptedText, setDecryptedText] = useState<string | null>(null);
  const [isEncrypting, setIsEncrypting] = useState<boolean>(false);
  const [isDecrypting, setIsDecrypting] = useState<boolean>(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const sourceNode = CRITICAL_NODES.find(n => n.id === sourceNodeId) || CRITICAL_NODES[0];
  const targetNode = CRITICAL_NODES.find(n => n.id === targetNodeId) || CRITICAL_NODES[1];

  const handleCopy = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    soundFx.playClick();
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleEncrypt = async () => {
    if (!activeKey) {
      alert('Please generate or select a Quantum Key first.');
      return;
    }
    if (!plaintextInput.trim()) {
      alert('Please enter a sensitive command to encrypt.');
      return;
    }

    setIsEncrypting(true);
    soundFx.playClick();
    setDecryptedText(null);

    try {
      if (selectedAlgorithm === 'OTP') {
        const result = encryptOneTimePad(plaintextInput, activeKey.keyBytes, activeKey.keyId);
        setEncryptionResult(result);
      } else {
        const result = await encryptAesGcm(plaintextInput, activeKey.keyBytes, activeKey.keyId);
        setEncryptionResult(result);
      }
      soundFx.playKeyGenerated();
      if (onKeyConsumed) onKeyConsumed();
    } catch (err: unknown) {
      alert('Encryption failed: ' + (err instanceof Error ? err.message : String(err)));
    } finally {
      setIsEncrypting(false);
    }
  };

  const handleDecrypt = async () => {
    if (!encryptionResult || !activeKey) return;

    setIsDecrypting(true);
    soundFx.playClick();

    try {
      if (encryptionResult.algorithm === 'OTP') {
        const plain = decryptOneTimePad(encryptionResult.ciphertextHex, activeKey.keyBytes);
        setDecryptedText(plain);
      } else {
        if (!encryptionResult.ivHex) throw new Error('Missing IV for AES-GCM');
        const plain = await decryptAesGcm(
          encryptionResult.ciphertextHex, 
          encryptionResult.ivHex, 
          activeKey.keyBytes
        );
        setDecryptedText(plain);
      }
      soundFx.playDecryptSuccess();
    } catch (err: unknown) {
      alert('Decryption failed: ' + (err instanceof Error ? err.message : String(err)));
    } finally {
      setIsDecrypting(false);
    }
  };

  return (
    <div className="bg-[#0f172a]/60 border border-slate-800 rounded-lg p-4 sm:p-5 cyber-panel-glow">
      {/* Panel Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 mb-4 border-b border-slate-800 gap-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded bg-[#020617] border border-emerald-500/40 text-emerald-400">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xs uppercase text-slate-400 tracking-widest font-bold font-mono">
                Live Encryption Sandbox
              </h2>
              <span className="tag-immersive border-emerald-500/50 text-emerald-400">
                QKD QUANTUM-SECURED
              </span>
            </div>
            <p className="text-sm font-bold text-white tracking-wide font-mono">
              One-Time Pad & AES-256-GCM Mission Control
            </p>
          </div>
        </div>

        {/* Algorithm Selection */}
        <div className="flex items-center bg-[#020617] rounded p-1 border border-slate-800 text-xs font-mono">
          <span className="text-slate-400 px-2 select-none uppercase text-[10px]">Cipher:</span>
          <button
            onClick={() => {
              setSelectedAlgorithm('OTP');
              soundFx.playClick();
              setEncryptionResult(null);
              setDecryptedText(null);
            }}
            className={`px-3 py-1 rounded transition-all text-[11px] uppercase tracking-wider ${
              selectedAlgorithm === 'OTP' 
                ? 'bg-[#0f172a] text-emerald-300 border border-emerald-500/50 font-bold' 
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="One-Time Pad: Mathematical Information-Theoretic Security"
          >
            One-Time Pad (OTP)
          </button>
          <button
            onClick={() => {
              setSelectedAlgorithm('AES-256-GCM');
              soundFx.playClick();
              setEncryptionResult(null);
              setDecryptedText(null);
            }}
            className={`px-3 py-1 rounded transition-all text-[11px] uppercase tracking-wider ${
              selectedAlgorithm === 'AES-256-GCM' 
                ? 'bg-[#0f172a] text-emerald-300 border border-emerald-500/50 font-bold' 
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="AES-256-GCM: Authenticated Encryption using QKD Seed"
          >
            AES-256-GCM
          </button>
        </div>
      </div>

      {/* Preset Command Buttons */}
      <div className="mb-3 space-y-1.5 font-mono">
        <div className="text-[11px] text-slate-400 flex items-center justify-between uppercase tracking-wider font-bold">
          <span>Critical Infrastructure Payload Presets:</span>
          <span className="text-[10px] text-slate-500">Click to load</span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {COMMAND_PRESETS.map((preset, i) => (
            <button
              key={i}
              onClick={() => {
                setPlaintextInput(preset.command);
                soundFx.playClick();
                setEncryptionResult(null);
                setDecryptedText(null);
              }}
              className="px-2.5 py-1 rounded bg-[#020617] border border-slate-800 hover:border-cyan-500/50 text-[11px] text-slate-300 hover:text-cyan-300 transition-colors uppercase font-bold"
            >
              {preset.category}
            </button>
          ))}
        </div>
      </div>

      {/* Plaintext Command Input */}
      <div className="space-y-3 font-mono">
        <div className="bg-[#020617] border border-slate-800 rounded-lg p-3.5 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="text-cyan-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5" /> Plaintext Payload (Source SAE: {sourceNode.saeId}):
            </span>
            <span className="tag-immersive">
              {plaintextInput.length} chars ({plaintextInput.length * 8} bits)
            </span>
          </div>
          <textarea
            id="sensitive-command-input"
            rows={2}
            value={plaintextInput}
            onChange={(e) => {
              setPlaintextInput(e.target.value);
              setEncryptionResult(null);
              setDecryptedText(null);
            }}
            placeholder="Enter sensitive command (e.g. Grid Voltage Command: 220V)..."
            className="w-full bg-[#000] border-l-3 border-emerald-500 text-emerald-400 p-3 rounded text-xs font-mono focus:outline-none focus:border-cyan-500 leading-relaxed resize-none shadow-inner"
          />

          {/* Action Buttons: Encrypt with QKD Key */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
            <div className="text-xs text-slate-400 flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-cyan-400" />
              <span className="uppercase text-[11px]">Active Key:</span>
              {activeKey ? (
                <span className="text-cyan-300 font-bold truncate max-w-[200px] sm:max-w-xs">
                  {activeKey.keyId.substring(0, 24)}...
                </span>
              ) : (
                <span className="text-amber-400 font-bold">No Key Harvested Yet</span>
              )}
            </div>

            <button
              id="encrypt-command-button"
              onClick={handleEncrypt}
              disabled={isEncrypting || !activeKey}
              className="px-4 py-2 rounded bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-bold uppercase tracking-wider flex items-center gap-2 shadow-[0_0_15px_rgba(16,185,129,0.4)] active:scale-95 transition-all disabled:opacity-50 cursor-pointer"
            >
              {isEncrypting ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-black" />
                  <span>Encrypting via QKD...</span>
                </>
              ) : (
                <>
                  <Lock className="w-3.5 h-3.5 text-black" />
                  <span>Encrypt with Active Key</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Cryptographic Pipeline Visualizer (When Encrypted) */}
        {encryptionResult && (
          <div className="space-y-3 animate-fadeIn">
            
            {/* Step-by-Step Bitwise XOR & Transformation Breakdown */}
            <div className="bg-[#020617] border border-slate-800 rounded-lg p-3.5 space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span className="text-emerald-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5" /> Pipeline Execution ({encryptionResult.algorithm})
                </span>
                <span className="tag-immersive border-cyan-500/50 text-cyan-300">
                  SHANNON PERFECT SECRECY
                </span>
              </div>

              {/* Bitwise Matrix */}
              <div className="bg-[#000] border-l-3 border-emerald-500 rounded p-3 space-y-2 font-mono text-xs">
                <div className="grid grid-cols-1 md:grid-cols-12 gap-2 items-center">
                  <div className="md:col-span-3 text-slate-400 text-[11px] uppercase">Plaintext (8B):</div>
                  <div className="md:col-span-9 text-cyan-300 text-[11px] bg-[#0f172a] px-2.5 py-1 rounded border border-slate-800">
                    {encryptionResult.binaryPlaintext}
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-12 gap-2 items-center">
                  <div className="md:col-span-3 text-slate-400 text-[11px] uppercase">Quantum Key (Bits):</div>
                  <div className="md:col-span-9 text-purple-300 text-[11px] bg-[#0f172a] px-2.5 py-1 rounded border border-slate-800">
                    {encryptionResult.binaryKey}
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-12 gap-2 items-center border-t border-slate-800 pt-1.5">
                  <div className="md:col-span-3 text-emerald-400 text-[11px] font-bold uppercase">
                    {selectedAlgorithm === 'OTP' ? 'Bitwise XOR (⊕):' : 'AES-GCM Cipher:'}
                  </div>
                  <div className="md:col-span-9 text-emerald-300 text-[11px] bg-[#0f172a] border border-emerald-500/40 px-2.5 py-1 rounded font-bold">
                    {encryptionResult.binaryCiphertext}
                  </div>
                </div>
              </div>

              {/* Ciphertext Output Box */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span className="uppercase text-[11px] font-bold">Transmitted Ciphertext (Hex Encoded):</span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleCopy(encryptionResult.ciphertextHex, 'cipherHex')}
                      className="text-[10px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 uppercase font-bold"
                    >
                      {copiedField === 'cipherHex' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedField === 'cipherHex' ? 'Copied' : 'Copy Hex'}</span>
                    </button>
                  </div>
                </div>
                <div 
                  id="ciphertext-output"
                  className="hex-block-immersive select-all text-xs tracking-wider"
                >
                  {encryptionResult.ciphertextHex}
                </div>
              </div>

              {/* GCM Extra Metadata if applicable */}
              {encryptionResult.ivHex && (
                <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400">
                  <div className="bg-[#0f172a] p-2 rounded border border-slate-800">
                    <span className="text-slate-500">GCM IV (96b):</span> <span className="text-cyan-300">{encryptionResult.ivHex}</span>
                  </div>
                  <div className="bg-[#0f172a] p-2 rounded border border-slate-800">
                    <span className="text-slate-500">Auth Tag (128b):</span> <span className="text-emerald-300">{encryptionResult.authTagHex}</span>
                  </div>
                </div>
              )}

              {/* Decrypt Action Button */}
              <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
                <div className="text-xs text-slate-400">
                  Target Node: <strong className="text-emerald-300">{targetNode.name}</strong> ({targetNode.saeId})
                </div>
                <button
                  id="decrypt-command-button"
                  onClick={handleDecrypt}
                  disabled={isDecrypting}
                  className="px-4 py-2 rounded bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-bold uppercase tracking-wider flex items-center gap-2 shadow-[0_0_15px_rgba(6,182,212,0.3)] active:scale-95 transition-all cursor-pointer"
                >
                  {isDecrypting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Decrypting at Target KME...</span>
                    </>
                  ) : (
                    <>
                      <Unlock className="w-3.5 h-3.5" />
                      <span>Decrypt & Verify Integrity</span>
                    </>
                  )}
                </button>
              </div>

            </div>

            {/* Verified Decrypted Output Box */}
            {decryptedText && (
              <div className="bg-[#020617] border-2 border-emerald-500 rounded-lg p-4 space-y-2 animate-fadeIn shadow-[0_0_20px_rgba(16,185,129,0.2)]">
                <div className="flex items-center justify-between text-xs text-emerald-400 font-bold">
                  <span className="flex items-center gap-1.5 uppercase tracking-wide">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    DECRYPTION SUCCESSFUL & INTEGRITY VERIFIED
                  </span>
                  <span className="tag-immersive border-emerald-500 text-emerald-300 font-bold">
                    MATCH: 100% BIT-FOR-BIT
                  </span>
                </div>
                <div 
                  id="decrypted-plaintext-output"
                  className="bg-[#000] border-l-3 border-emerald-500 text-emerald-400 text-xs sm:text-sm p-3 rounded break-all leading-relaxed font-mono"
                >
                  {decryptedText}
                </div>
                <p className="text-[11px] text-slate-400">
                  Command authenticated and executed with zero eavesdropping trace. Quantum Key token securely retired according to One-Time Pad mandate.
                </p>
              </div>
            )}

          </div>
        )}
      </div>
    </div>
  );
};
