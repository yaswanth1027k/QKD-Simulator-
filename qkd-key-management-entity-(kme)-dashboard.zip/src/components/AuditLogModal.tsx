import React, { useState } from 'react';
import { 
  Layers, 
  X, 
  Trash2, 
  Download, 
  Filter, 
  AlertTriangle, 
  CheckCircle, 
  Info, 
  Flame,
  ShieldCheck
} from 'lucide-react';
import { AuditLogEntry } from '../types/qkd';
import { soundFx } from '../utils/qkdCrypto';

interface AuditLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  logs: AuditLogEntry[];
  onClearLogs: () => void;
}

export const AuditLogModal: React.FC<AuditLogModalProps> = ({
  isOpen,
  onClose,
  logs,
  onClearLogs
}) => {
  const [selectedLevel, setSelectedLevel] = useState<string>('ALL');

  if (!isOpen) return null;

  const filteredLogs = selectedLevel === 'ALL' 
    ? logs 
    : logs.filter(l => l.level === selectedLevel);

  const exportLogsAsJson = () => {
    soundFx.playClick();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(logs, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `qkd-kme-audit-log-${new Date().toISOString()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const getLevelBadge = (level: AuditLogEntry['level']) => {
    switch (level) {
      case 'CRITICAL':
        return <span className="tag-immersive border-red-500 text-red-400 bg-red-950/80 font-bold">CRITICAL</span>;
      case 'WARN':
        return <span className="tag-immersive border-amber-500 text-amber-400 bg-amber-950/80 font-bold">WARN</span>;
      case 'SUCCESS':
        return <span className="tag-immersive border-emerald-500 text-emerald-400 bg-emerald-950/80 font-bold">SUCCESS</span>;
      default:
        return <span className="tag-immersive border-slate-700 text-slate-400">INFO</span>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#020617]/85 backdrop-blur-sm animate-fadeIn font-mono">
      <div className="bg-[#0f172a] border border-slate-800 rounded-lg w-full max-w-4xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden cyber-panel-glow">
        
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-[#020617]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded bg-[#0f172a] border border-cyan-500/40 text-cyan-400">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xs uppercase text-slate-400 tracking-widest font-bold font-mono">
                  Audit Trail & Security Register
                </h3>
                <span className="tag-immersive border-cyan-500/50 text-cyan-400">
                  ETSI GS QKD 014
                </span>
              </div>
              <p className="text-sm font-bold text-white tracking-wide font-mono">
                Decoupled Quantum Transaction Log & Relay Register
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundFx.playClick();
              onClose();
            }}
            className="p-2 rounded bg-[#020617] hover:bg-slate-800 text-slate-400 hover:text-white transition-colors border border-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter & Actions Bar */}
        <div className="p-3 bg-[#020617]/80 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2 px-4 sm:px-5">
          <div className="flex items-center gap-1.5 text-xs font-mono">
            <Filter className="w-3.5 h-3.5 text-slate-400 mr-1" />
            {['ALL', 'CRITICAL', 'WARN', 'SUCCESS', 'INFO'].map((lvl) => (
              <button
                key={lvl}
                onClick={() => {
                  soundFx.playClick();
                  setSelectedLevel(lvl);
                }}
                className={`px-2.5 py-1 rounded transition-all uppercase tracking-wider text-[10px] font-bold cursor-pointer ${
                  selectedLevel === lvl
                    ? 'bg-[#0f172a] text-cyan-300 border border-cyan-500/60 font-bold'
                    : 'text-slate-400 hover:text-slate-200 border border-transparent'
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={exportLogsAsJson}
              className="px-3 py-1.5 rounded bg-[#020617] hover:bg-slate-900 text-cyan-300 text-xs font-mono flex items-center gap-1.5 transition-colors border border-cyan-500/40 uppercase font-bold tracking-wider cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export JSON</span>
            </button>
            <button
              onClick={() => {
                soundFx.playClick();
                onClearLogs();
              }}
              className="px-3 py-1.5 rounded bg-[#020617] hover:bg-red-950/60 text-red-400 text-xs font-mono flex items-center gap-1.5 transition-colors border border-red-500/40 uppercase font-bold tracking-wider cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Log</span>
            </button>
          </div>
        </div>

        {/* Log Stream Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-2 font-mono text-xs max-h-[55vh]">
          {filteredLogs.length > 0 ? (
            filteredLogs.map((entry) => (
              <div 
                key={entry.id}
                className="p-2.5 rounded bg-[#020617] border border-slate-800/80 hover:border-cyan-500/40 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div className="flex items-start gap-2.5">
                  <div className="mt-0.5">{getLevelBadge(entry.level)}</div>
                  <div>
                    <span className="text-[11px] text-slate-500 mr-2">
                      [{new Date(entry.timestamp).toLocaleTimeString()}]
                    </span>
                    <span className="text-[11px] font-bold text-cyan-400 mr-2">
                      &lt;{entry.category}&gt;
                    </span>
                    <span className="text-slate-200">{entry.message}</span>
                    {entry.details && (
                      <p className="text-[10px] text-slate-400 mt-1 pl-2 border-l-2 border-slate-700 font-mono">
                        {entry.details}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="p-8 text-center text-slate-500 font-mono">
              No audit logs recorded for filter: {selectedLevel}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
