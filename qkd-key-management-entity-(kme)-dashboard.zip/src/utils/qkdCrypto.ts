import { QuantumKeyMaterial, NodeId, EncryptionResult } from '../types/qkd';

// Audio Synthesizer via Web Audio API for tactical cybersecurity feedback
class SoundFX {
  private ctx: AudioContext | null = null;
  public enabled: boolean = true;

  private initCtx() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  playKeyGenerated() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, this.ctx.currentTime); // A5
      osc.frequency.exponentialRampToValueAtTime(1760, this.ctx.currentTime + 0.12); // A6
      gain.gain.setValueAtTime(0.08, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.15);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.15);
    } catch {
      // ignore
    }
  }

  playAttackAlarm() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(440, this.ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(880, this.ctx.currentTime + 0.1);
      osc.frequency.linearRampToValueAtTime(440, this.ctx.currentTime + 0.2);
      gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.01, this.ctx.currentTime + 0.25);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.25);
    } catch {
      // ignore
    }
  }

  playClick() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(1200, this.ctx.currentTime);
      gain.gain.setValueAtTime(0.03, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.04);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.04);
    } catch {
      // ignore
    }
  }

  playDecryptSuccess() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      [523.25, 659.25, 783.99, 1046.5].forEach((freq, i) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + i * 0.04);
        gain.gain.setValueAtTime(0.05, now + i * 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.04 + 0.15);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now + i * 0.04);
        osc.stop(now + i * 0.04 + 0.15);
      });
    } catch {
      // ignore
    }
  }
}

export const soundFx = new SoundFX();

// Calculate Shannon Entropy of key byte array (target is close to 8.0 bits per byte for true quantum randomness)
export function calculateShannonEntropy(bytes: number[]): number {
  if (!bytes || bytes.length === 0) return 0;
  const frequencies = new Map<number, number>();
  for (const byte of bytes) {
    frequencies.set(byte, (frequencies.get(byte) || 0) + 1);
  }
  let entropy = 0;
  for (const count of frequencies.values()) {
    const p = count / bytes.length;
    entropy -= p * Math.log2(p);
  }
  return Number(entropy.toFixed(3));
}

// Convert byte array to formatted Hex string
export function bytesToHex(bytes: number[]): string {
  return Array.from(bytes)
    .map(b => b.toString(16).padStart(2, '0').toUpperCase())
    .join('');
}

// Convert Hex string to byte array
export function hexToBytes(hex: string): number[] {
  const cleanHex = hex.replace(/[^0-9a-fA-F]/g, '');
  const bytes: number[] = [];
  for (let i = 0; i < cleanHex.length; i += 2) {
    bytes.push(parseInt(cleanHex.substring(i, i + 2), 16));
  }
  return bytes;
}

// Convert UTF-8 string to byte array
export function stringToBytes(str: string): number[] {
  const encoder = new TextEncoder();
  return Array.from(encoder.encode(str));
}

// Convert byte array to UTF-8 string
export function bytesToString(bytes: number[]): string {
  const decoder = new TextDecoder();
  return decoder.decode(new Uint8Array(bytes));
}

// Convert bytes to Binary string (e.g. "01001000 01100101...")
export function bytesToBinaryString(bytes: number[], maxBytes: number = 8): string {
  return Array.from(bytes.slice(0, maxBytes))
    .map(b => b.toString(2).padStart(8, '0'))
    .join(' ') + (bytes.length > maxBytes ? ' ...' : '');
}

// Generate Secure Mock Quantum Key compliant with ETSI GS QKD 014
export function generateLocalQuantumKey(
  sourceNode: NodeId = 'substation-alpha',
  targetNode: NodeId = 'data-center-central',
  sourceSaeId: string = 'SAE_GRID_A_101',
  targetSaeId: string = 'SAE_CORE_VAULT_909',
  bitLength: number = 256
): QuantumKeyMaterial {
  const byteCount = bitLength / 8;
  const keyBytes = new Uint8Array(byteCount);
  
  if (typeof window !== 'undefined' && window.crypto) {
    window.crypto.getRandomValues(keyBytes);
  } else {
    for (let i = 0; i < byteCount; i++) {
      keyBytes[i] = Math.floor(Math.random() * 256);
    }
  }

  const bytesArray = Array.from(keyBytes);
  const hex = bytesToHex(bytesArray);
  const timestamp = new Date().toISOString();
  
  // Format ETSI standard UUID: urn:etsi:qkd:014:key:xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx
  const uuid = 'urn:etsi:qkd:014:key:' + 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });

  return {
    keyId: uuid,
    keyHex: hex,
    keyBytes: bytesArray,
    keyBitLength: bitLength,
    timestamp,
    sourceNodeId: sourceNode,
    targetNodeId: targetNode,
    sourceSaeId,
    targetSaeId,
    ttlSeconds: 300,
    remainingTtl: 300,
    entropyBits: calculateShannonEntropy(bytesArray),
    protocol: 'ETSI-GS-QKD-014',
    origin: 'LOCAL_FALLBACK'
  };
}

// One-Time Pad (OTP) Bitwise XOR Encryption
export function encryptOneTimePad(plaintext: string, keyBytes: number[], keyId: string): EncryptionResult {
  const plainBytes = stringToBytes(plaintext);
  if (plainBytes.length === 0) {
    throw new Error('Plaintext cannot be empty');
  }

  // OTP requires key length >= plaintext length
  const cipherBytes: number[] = [];
  const binaryPlainList: string[] = [];
  const binaryCipherList: string[] = [];
  const binaryKeyList: string[] = [];

  for (let i = 0; i < plainBytes.length; i++) {
    const pByte = plainBytes[i];
    // In QKD OTP, key stream repeats or exhausts the quantum key
    const kByte = keyBytes[i % keyBytes.length];
    const cByte = pByte ^ kByte; // XOR Operation
    cipherBytes.push(cByte);

    if (i < 8) {
      binaryPlainList.push(pByte.toString(2).padStart(8, '0'));
      binaryKeyList.push(kByte.toString(2).padStart(8, '0'));
      binaryCipherList.push(cByte.toString(2).padStart(8, '0'));
    }
  }

  const ciphertextHex = bytesToHex(cipherBytes);
  // Base64 encoding
  const binaryString = String.fromCharCode(...cipherBytes);
  const ciphertextBase64 = btoa(binaryString);

  return {
    algorithm: 'OTP',
    plaintext,
    ciphertextHex,
    ciphertextBase64,
    usedKeyId: keyId,
    timestamp: new Date().toISOString(),
    binaryPlaintext: binaryPlainList.join(' '),
    binaryKey: binaryKeyList.join(' '),
    binaryCiphertext: binaryCipherList.join(' ')
  };
}

// One-Time Pad Decryption (c ^ k = p)
export function decryptOneTimePad(ciphertextHex: string, keyBytes: number[]): string {
  const cipherBytes = hexToBytes(ciphertextHex);
  const plainBytes: number[] = [];
  for (let i = 0; i < cipherBytes.length; i++) {
    const cByte = cipherBytes[i];
    const kByte = keyBytes[i % keyBytes.length];
    plainBytes.push(cByte ^ kByte);
  }
  return bytesToString(plainBytes);
}

// AES-256-GCM Encryption using Web Crypto API with QKD Key
export async function encryptAesGcm(plaintext: string, keyBytes: number[], keyId: string): Promise<EncryptionResult> {
  const plainBytes = new TextEncoder().encode(plaintext);
  // Make sure we have 32 bytes (256 bits) for AES-256
  const key32 = new Uint8Array(32);
  for (let i = 0; i < 32; i++) {
    key32[i] = keyBytes[i % keyBytes.length];
  }

  // 12 bytes IV for GCM
  const iv = new Uint8Array(12);
  window.crypto.getRandomValues(iv);

  const cryptoKey = await window.crypto.subtle.importKey(
    'raw',
    key32,
    { name: 'AES-GCM' },
    false,
    ['encrypt', 'decrypt']
  );

  const encryptedBuffer = await window.crypto.subtle.encrypt(
    {
      name: 'AES-GCM',
      iv,
      tagLength: 128
    },
    cryptoKey,
    plainBytes
  );

  const encryptedBytes = new Uint8Array(encryptedBuffer);
  // In Web Crypto AES-GCM, the last 16 bytes are the auth tag
  const cipherOnly = encryptedBytes.slice(0, encryptedBytes.length - 16);
  const authTag = encryptedBytes.slice(encryptedBytes.length - 16);

  const fullCipherHex = bytesToHex(Array.from(encryptedBytes));
  const ivHex = bytesToHex(Array.from(iv));
  const authTagHex = bytesToHex(Array.from(authTag));

  const binaryString = String.fromCharCode(...encryptedBytes);
  const ciphertextBase64 = btoa(binaryString);

  return {
    algorithm: 'AES-256-GCM',
    plaintext,
    ciphertextHex: fullCipherHex,
    ciphertextBase64,
    ivHex,
    authTagHex,
    usedKeyId: keyId,
    timestamp: new Date().toISOString(),
    binaryPlaintext: bytesToBinaryString(Array.from(plainBytes), 8),
    binaryKey: bytesToBinaryString(Array.from(key32), 8),
    binaryCiphertext: bytesToBinaryString(Array.from(cipherOnly), 8)
  };
}

// AES-256-GCM Decryption using Web Crypto API
export async function decryptAesGcm(ciphertextHex: string, ivHex: string, keyBytes: number[]): Promise<string> {
  const cipherBytes = new Uint8Array(hexToBytes(ciphertextHex));
  const ivBytes = new Uint8Array(hexToBytes(ivHex));
  
  const key32 = new Uint8Array(32);
  for (let i = 0; i < 32; i++) {
    key32[i] = keyBytes[i % keyBytes.length];
  }

  const cryptoKey = await window.crypto.subtle.importKey(
    'raw',
    key32,
    { name: 'AES-GCM' },
    false,
    ['decrypt']
  );

  const decryptedBuffer = await window.crypto.subtle.decrypt(
    {
      name: 'AES-GCM',
      iv: ivBytes,
      tagLength: 128
    },
    cryptoKey,
    cipherBytes
  );

  return new TextDecoder().decode(decryptedBuffer);
}
