import { CriticalNode } from '../types/qkd';

export const CRITICAL_NODES: CriticalNode[] = [
  {
    id: 'substation-alpha',
    name: 'Power Substation Alpha (HV-Grid Relay)',
    category: 'Power Utility',
    saeId: 'SAE_GRID_A_101',
    location: 'Sector 7 Transmission Hub',
    distanceKm: 45.2,
    status: 'ONLINE',
    iconType: 'Zap',
    voltageOrSpec: '500 kV EHV / SCADA Relay IEC 61850'
  },
  {
    id: 'data-center-central',
    name: 'Central Secretariat Data Center',
    category: 'Data Center',
    saeId: 'SAE_CORE_VAULT_909',
    location: 'Federal Secure Vault - Room B3',
    distanceKm: 0.0,
    status: 'ONLINE',
    iconType: 'Server',
    voltageOrSpec: 'Tier IV Tier-Classified / HSM Key-Core'
  },
  {
    id: 'hydro-reservoir',
    name: 'Municipal Hydro Reservoir & Floodgate Gate-2',
    category: 'Water System',
    saeId: 'SAE_HYDRO_VALVE_402',
    location: 'North Aqueduct Dam Station',
    distanceKm: 68.7,
    status: 'ONLINE',
    iconType: 'Droplets',
    voltageOrSpec: '12,000 m³/s Spillway Flow Controls'
  },
  {
    id: 'fed-clearinghouse',
    name: 'Federal Reserve Financial Clearinghouse',
    category: 'Finance',
    saeId: 'SAE_FED_SETTLE_880',
    location: 'Financial District Tier-1 Node',
    distanceKm: 24.5,
    status: 'ONLINE',
    iconType: 'Landmark',
    voltageOrSpec: 'ISO 20022 High-Value Fedwire Link'
  },
  {
    id: 'metro-emergency',
    name: 'Metropolitan 911 Emergency Command Dispatch',
    category: 'Emergency',
    saeId: 'SAE_EMERG_CAD_704',
    location: 'Civil Defense Headquarters',
    distanceKm: 31.8,
    status: 'ONLINE',
    iconType: 'Radio',
    voltageOrSpec: 'P25 Phase 2 Encrypted Trunking'
  },
  {
    id: 'nuclear-unit-4',
    name: 'Nuclear Power Generation Station Unit 4',
    category: 'Nuclear',
    saeId: 'SAE_NUC_REACTOR_004',
    location: 'Coastal Generation Complex',
    distanceKm: 92.4,
    status: 'STANDBY',
    iconType: 'Atom',
    voltageOrSpec: '1,150 MWe PWR Safety Instrumentation'
  }
];

export const COMMAND_PRESETS = [
  {
    category: 'Power Grid SCADA',
    command: 'GRID_CMD: 500kV TRANS_BUS_4 -> OPEN_BREAKER_SYNC [VOLTAGE: 520kV | LOAD: 840MW]',
    targetId: 'substation-alpha'
  },
  {
    category: 'Water System Telemetry',
    command: 'AQUEDUCT_GATE: OPEN_SLUICE_42 [ELEVATION: 412.5m | CHLORINE_DOSING: +0.18mg/L]',
    targetId: 'hydro-reservoir'
  },
  {
    category: 'Fedwire Interbank Settlement',
    command: 'FEDWIRE_SETTLEMENT: BATCH_TRX_9921 [AMOUNT: $450,000,000.00 USD -> FED_RESERVE_NY]',
    targetId: 'fed-clearinghouse'
  },
  {
    category: 'Civil Emergency Broadcast',
    command: 'EAS_DEFCON_ALERT: BROADCAST_CHANNEL_911 [PRIORITY: FLASH | AUTH: HOMELAND_KME_SEC]',
    targetId: 'metro-emergency'
  },
  {
    category: 'Nuclear Reactor Control',
    command: 'REACTOR_SCRAM_PARAM: INSERT_CONTROL_ROD_BANK_C [CORE_TEMP: 318°C | FLUX: 98.4%]',
    targetId: 'nuclear-unit-4'
  }
];
